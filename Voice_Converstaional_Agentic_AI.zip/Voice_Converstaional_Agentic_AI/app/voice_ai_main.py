import os
import time
import json
import logging
from datetime import datetime
from typing import List, Dict, Optional, Any
from pathlib import Path
import asyncio
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# Core libraries
import openai
from openai import OpenAI
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import faiss
import whisper
from gtts import gTTS
import pygame
from io import BytesIO
import tempfile
import wave
import pyaudio
import threading
from queue import Queue

# Document processing
import PyPDF2
import pandas as pd
import docx
from sentence_transformers import SentenceTransformer

# Environment management
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Voice Conversational Agentic AI",
    description="A Python-based RESTful API for bi-directional voice conversations with LLM and RAG capabilities",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize OpenAI client
openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Initialize sentence transformer for embeddings
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Initialize pygame for audio playback
pygame.mixer.init()

# Pydantic models
class TranscribeResponse(BaseModel):
    text: str
    processing_time: float
    confidence: Optional[float] = None

class ChatRequest(BaseModel):
    message: str
    conversation_history: Optional[List[Dict[str, str]]] = []
    rag_context: Optional[str] = None
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 1000

class ChatResponse(BaseModel):
    response: str
    processing_time: float
    tokens_used: Optional[int] = None
    rag_sources: Optional[List[str]] = []

class SpeakRequest(BaseModel):
    text: str
    voice: Optional[str] = "alloy"
    speed: Optional[float] = 1.0

class SpeakResponse(BaseModel):
    audio_url: str
    processing_time: float
    audio_duration: Optional[float] = None

class ConverseRequest(BaseModel):
    rag_context: Optional[str] = None
    voice_settings: Optional[Dict[str, Any]] = {}
    llm_settings: Optional[Dict[str, Any]] = {}

class ConverseResponse(BaseModel):
    transcription: str
    llm_response: str
    total_processing_time: float
    stt_time: float
    llm_time: float
    tts_time: float
    rag_sources: Optional[List[str]] = []

class DocumentUploadResponse(BaseModel):
    message: str
    documents_processed: int
    processing_time: float
    total_chunks: int

# Global variables for conversation memory and RAG
conversation_memory: List[Dict[str, str]] = []
rag_vectorstore = None
rag_documents = []
rag_index = None

class RAGManager:
    def __init__(self):
        self.documents = []
        self.embeddings = []
        self.index = None
        self.chunk_size = 1000
        self.chunk_overlap = 200
        
    def add_documents(self, documents: List[str], sources: List[str]):
        """Add documents to the RAG knowledge base"""
        chunks = []
        chunk_sources = []
        
        for doc, source in zip(documents, sources):
            doc_chunks = self._chunk_text(doc)
            chunks.extend(doc_chunks)
            chunk_sources.extend([source] * len(doc_chunks))
        
        # Generate embeddings
        new_embeddings = embedding_model.encode(chunks)
        
        if self.embeddings:
            self.embeddings = np.vstack([self.embeddings, new_embeddings])
        else:
            self.embeddings = new_embeddings
            
        self.documents.extend(chunks)
        
        # Update FAISS index
        self._update_index()
        
        return len(chunks)
    
    def _chunk_text(self, text: str) -> List[str]:
        """Split text into chunks"""
        words = text.split()
        chunks = []
        
        for i in range(0, len(words), self.chunk_size - self.chunk_overlap):
            chunk = ' '.join(words[i:i + self.chunk_size])
            chunks.append(chunk)
            
        return chunks
    
    def _update_index(self):
        """Update FAISS index with new embeddings"""
        if self.embeddings is not None and len(self.embeddings) > 0:
            dimension = self.embeddings.shape[1]
            self.index = faiss.IndexFlatIP(dimension)
            # Normalize embeddings for cosine similarity
            normalized_embeddings = self.embeddings / np.linalg.norm(self.embeddings, axis=1, keepdims=True)
            self.index.add(normalized_embeddings.astype('float32'))
    
    def search(self, query: str, top_k: int = 3) -> List[str]:
        """Search for relevant documents"""
        if not self.index or len(self.documents) == 0:
            return []
            
        query_embedding = embedding_model.encode([query])
        query_embedding = query_embedding / np.linalg.norm(query_embedding)
        
        scores, indices = self.index.search(query_embedding.astype('float32'), top_k)
        
        relevant_docs = []
        for idx in indices[0]:
            if idx < len(self.documents):
                relevant_docs.append(self.documents[idx])
                
        return relevant_docs
    
    def clear(self):
        """Clear all documents and embeddings"""
        self.documents = []
        self.embeddings = []
        self.index = None

# Initialize RAG manager
rag_manager = RAGManager()

class AudioProcessor:
    def __init__(self):
        self.sample_rate = 16000
        self.chunk_size = 1024
        self.channels = 1
        self.format = pyaudio.paInt16
        
    def record_audio(self, duration: int = 5) -> bytes:
        """Record audio from microphone"""
        p = pyaudio.PyAudio()
        
        stream = p.open(
            format=self.format,
            channels=self.channels,
            rate=self.sample_rate,
            input=True,
            frames_per_buffer=self.chunk_size
        )
        
        frames = []
        for _ in range(0, int(self.sample_rate / self.chunk_size * duration)):
            data = stream.read(self.chunk_size)
            frames.append(data)
            
        stream.stop_stream()
        stream.close()
        p.terminate()
        
        # Convert to bytes
        audio_data = b''.join(frames)
        return audio_data
    
    def play_audio(self, audio_data: bytes):
        """Play audio through speakers"""
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
                tmp_file.write(audio_data)
                tmp_file_path = tmp_file.name
            
            # Play using pygame
            pygame.mixer.music.load(tmp_file_path)
            pygame.mixer.music.play()
            
            # Wait for playback to finish
            while pygame.mixer.music.get_busy():
                time.sleep(0.1)
                
            # Clean up
            os.unlink(tmp_file_path)
            
        except Exception as e:
            logger.error(f"Error playing audio: {e}")
            raise

audio_processor = AudioProcessor()

def process_document(file_content: bytes, filename: str) -> str:
    """Process different document types and extract text"""
    text = ""
    
    try:
        if filename.lower().endswith('.pdf'):
            # Process PDF
            pdf_reader = PyPDF2.PdfReader(BytesIO(file_content))
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
                
        elif filename.lower().endswith('.txt'):
            # Process TXT
            text = file_content.decode('utf-8')
            
        elif filename.lower().endswith('.csv'):
            # Process CSV
            df = pd.read_csv(BytesIO(file_content))
            text = df.to_string()
            
        elif filename.lower().endswith('.json'):
            # Process JSON
            json_data = json.loads(file_content.decode('utf-8'))
            text = json.dumps(json_data, indent=2)
            
        elif filename.lower().endswith('.docx'):
            # Process DOCX
            doc = docx.Document(BytesIO(file_content))
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
                
        else:
            raise ValueError(f"Unsupported file type: {filename}")
            
    except Exception as e:
        logger.error(f"Error processing document {filename}: {e}")
        raise HTTPException(status_code=400, detail=f"Error processing document: {str(e)}")
    
    return text

# API Endpoints

@app.post("/transcribe", response_model=TranscribeResponse)
async def transcribe_audio(file: UploadFile = File(...)):
    """Transcribe audio file to text"""
    start_time = time.time()
    
    try:
        # Read audio file
        audio_content = await file.read()
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
            tmp_file.write(audio_content)
            tmp_file_path = tmp_file.name
        
        # Transcribe using OpenAI Whisper
        with open(tmp_file_path, 'rb') as audio_file:
            transcript = openai_client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                response_format="text"
            )
        
        # Clean up
        os.unlink(tmp_file_path)
        
        processing_time = time.time() - start_time
        
        return TranscribeResponse(
            text=transcript,
            processing_time=processing_time
        )
        
    except Exception as e:
        logger.error(f"Error in transcription: {e}")
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

@app.post("/chat", response_model=ChatResponse)
async def chat_with_llm(request: ChatRequest):
    """Chat with LLM using text input"""
    start_time = time.time()
    
    try:
        # Get RAG context if available
        rag_context = ""
        rag_sources = []
        
        if request.rag_context:
            relevant_docs = rag_manager.search(request.message, top_k=3)
            rag_context = "\n\n".join(relevant_docs)
            rag_sources = [f"Document chunk {i+1}" for i in range(len(relevant_docs))]
        
        # Build conversation history
        messages = []
        
        # Add system message with RAG context
        system_message = "You are a helpful AI assistant."
        if rag_context:
            system_message += f"\n\nRelevant context from documents:\n{rag_context}"
        
        messages.append({"role": "system", "content": system_message})
        
        # Add conversation history
        for msg in request.conversation_history:
            messages.append(msg)
            
        # Add current message
        messages.append({"role": "user", "content": request.message})
        
        # Get LLM response
        response = openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens
        )
        
        llm_response = response.choices[0].message.content
        tokens_used = response.usage.total_tokens
        
        # Update conversation memory
        global conversation_memory
        conversation_memory.append({"role": "user", "content": request.message})
        conversation_memory.append({"role": "assistant", "content": llm_response})
        
        processing_time = time.time() - start_time
        
        return ChatResponse(
            response=llm_response,
            processing_time=processing_time,
            tokens_used=tokens_used,
            rag_sources=rag_sources
        )
        
    except Exception as e:
        logger.error(f"Error in chat: {e}")
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)}")

@app.post("/speak", response_model=SpeakResponse)
async def text_to_speech(request: SpeakRequest):
    """Convert text to speech"""
    start_time = time.time()
    
    try:
        # Generate speech using OpenAI TTS
        response = openai_client.audio.speech.create(
            model="tts-1",
            voice=request.voice,
            input=request.text,
            speed=request.speed
        )
        
        # Save audio to temporary file
        with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_file:
            tmp_file.write(response.content)
            tmp_file_path = tmp_file.name
        
        processing_time = time.time() - start_time
        
        return SpeakResponse(
            audio_url=tmp_file_path,
            processing_time=processing_time
        )
        
    except Exception as e:
        logger.error(f"Error in TTS: {e}")
        raise HTTPException(status_code=500, detail=f"TTS failed: {str(e)}")

@app.post("/converse", response_model=ConverseResponse)
async def full_conversation_pipeline(
    audio_file: UploadFile = File(...),
    rag_context: Optional[str] = Form(None)
):
    """Complete voice conversation pipeline"""
    total_start_time = time.time()
    
    try:
        # Step 1: Transcribe audio
        stt_start = time.time()
        audio_content = await audio_file.read()
        
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
            tmp_file.write(audio_content)
            tmp_file_path = tmp_file.name
        
        with open(tmp_file_path, 'rb') as audio_file_obj:
            transcript = openai_client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file_obj,
                response_format="text"
            )
        
        os.unlink(tmp_file_path)
        stt_time = time.time() - stt_start
        
        # Step 2: Process with LLM
        llm_start = time.time()
        
        # Get RAG context
        rag_sources = []
        if rag_context:
            relevant_docs = rag_manager.search(transcript, top_k=3)
            rag_context = "\n\n".join(relevant_docs)
            rag_sources = [f"Document chunk {i+1}" for i in range(len(relevant_docs))]
        
        # Build messages
        messages = [
            {"role": "system", "content": "You are a helpful AI assistant."}
        ]
        
        if rag_context:
            messages[0]["content"] += f"\n\nRelevant context:\n{rag_context}"
        
        # Add conversation history
        messages.extend(conversation_memory[-10:])  # Keep last 10 messages
        messages.append({"role": "user", "content": transcript})
        
        # Get LLM response
        response = openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.7,
            max_tokens=1000
        )
        
        llm_response = response.choices[0].message.content
        llm_time = time.time() - llm_start
        
        # Step 3: Convert to speech
        tts_start = time.time()
        speech_response = openai_client.audio.speech.create(
            model="tts-1",
            voice="alloy",
            input=llm_response
        )
        
        # Play audio
        audio_processor.play_audio(speech_response.content)
        tts_time = time.time() - tts_start
        
        # Update conversation memory
        global conversation_memory
        conversation_memory.append({"role": "user", "content": transcript})
        conversation_memory.append({"role": "assistant", "content": llm_response})
        
        total_processing_time = time.time() - total_start_time
        
        return ConverseResponse(
            transcription=transcript,
            llm_response=llm_response,
            total_processing_time=total_processing_time,
            stt_time=stt_time,
            llm_time=llm_time,
            tts_time=tts_time,
            rag_sources=rag_sources
        )
        
    except Exception as e:
        logger.error(f"Error in conversation pipeline: {e}")
        raise HTTPException(status_code=500, detail=f"Conversation failed: {str(e)}")

@app.post("/reset")
async def reset_conversation():
    """Reset conversation memory"""
    global conversation_memory
    conversation_memory = []
    return {"message": "Conversation memory reset successfully"}

@app.post("/upload_rag_docs", response_model=DocumentUploadResponse)
async def upload_rag_documents(files: List[UploadFile] = File(...)):
    """Upload documents for RAG knowledge base"""
    start_time = time.time()
    
    try:
        documents = []
        sources = []
        
        for file in files:
            # Read file content
            file_content = await file.read()
            
            # Process document
            text = process_document(file_content, file.filename)
            documents.append(text)
            sources.append(file.filename)
        
        # Add to RAG manager
        total_chunks = rag_manager.add_documents(documents, sources)
        
        processing_time = time.time() - start_time
        
        return DocumentUploadResponse(
            message=f"Successfully processed {len(documents)} documents",
            documents_processed=len(documents),
            processing_time=processing_time,
            total_chunks=total_chunks
        )
        
    except Exception as e:
        logger.error(f"Error uploading documents: {e}")
        raise HTTPException(status_code=500, detail=f"Document upload failed: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "conversation_memory_size": len(conversation_memory),
        "rag_documents_count": len(rag_manager.documents)
    }

@app.get("/conversation_history")
async def get_conversation_history():
    """Get current conversation history"""
    return {
        "history": conversation_memory,
        "total_messages": len(conversation_memory)
    }

@app.delete("/clear_rag")
async def clear_rag_knowledge():
    """Clear RAG knowledge base"""
    rag_manager.clear()
    return {"message": "RAG knowledge base cleared successfully"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")