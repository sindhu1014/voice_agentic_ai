# OpenAI Configuration
OPENAI_API_KEY=sk-your-openai-api-key-here
OPENAI_MODEL=gpt-3.5-turbo
OPENAI_WHISPER_MODEL=whisper-1
OPENAI_TTS_MODEL=tts-1

# Alternative cloud providers (optional)
AZURE_SPEECH_KEY=your-azure-speech-key
AZURE_SPEECH_REGION=your-azure-region
GOOGLE_CLOUD_PROJECT=your-google-cloud-project
GOOGLE_APPLICATION_CREDENTIALS=path/to/your/service-account.json

# Vector Database Configuration
PINECONE_API_KEY=your-pinecone-api-key
PINECONE_ENVIRONMENT=your-pinecone-environment
WEAVIATE_URL=your-weaviate-cluster-url
WEAVIATE_API_KEY=your-weaviate-api-key

# Application Configuration
APP_HOST=0.0.0.0
APP_PORT=8000
APP_DEBUG=False
LOG_LEVEL=INFO

# RAG Configuration
RAG_CHUNK_SIZE=1000
RAG_CHUNK_OVERLAP=200
RAG_TOP_K=3
EMBEDDING_MODEL=all-MiniLM-L6-v2

# Audio Configuration
AUDIO_SAMPLE_RATE=16000
AUDIO_CHUNK_SIZE=1024
AUDIO_CHANNELS=1
DEFAULT_VOICE=alloy
DEFAULT_SPEECH_SPEED=1.0

# LLM Configuration
DEFAULT_TEMPERATURE=0.7
DEFAULT_MAX_TOKENS=1000
MAX_CONVERSATION_HISTORY=20

# File Upload Configuration
MAX_FILE_SIZE=10485760  # 10MB
ALLOWED_EXTENSIONS=pdf,txt,csv,json,docx
UPLOAD_DIRECTORY=uploads

# Security (for production)
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30